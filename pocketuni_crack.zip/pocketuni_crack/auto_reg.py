import requests
import random
from lxml import etree

def gen_last_num(fore_nums):
    LAST_NUM = ["1","0","X","9","8","7","6","5","4","3","2"]
    COEFF = [7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2]
    separate_num = list(range(17))
    SUM = 0
    for i in range(17):
        separate_num[i] = int(fore_nums[i])
        SUM = separate_num[i]*COEFF[i] + SUM
    LAST = SUM % 11
    return LAST_NUM[LAST]

def gen_fore_num():
    district = ["110000","120000","310000","500000"]
    district_name = ["北京","天津","上海","重庆"]
    district_i = random.randint(0,3)
    # print(district_name[district_i])
    year = str(random.randint(1997,1998))
    month = str(random.randint(1,12))
    day = str(random.randint(1,28))
    serial = str(random.randint(1,99))
    if int(serial[-1])%2 is 0:
        gender = "0"
    else:
        gender = "1"
    final_num = district[district_i] + year + month.zfill(2) + day.zfill(2) + serial.zfill(3)
    return gender,district_name[district_i],final_num

def auto_reg(number):
    login_url = "http://pocketuni.net/index.php?app=home&mod=Public&act=doLogin"
    form_data = {
        "sid":"588",
        "number":number,
        "password":"111111",
    }
    login_headers = {
        "Host": "pocketuni.net",
        "Origin": "http://pocketuni.net",
        "Referer": "http://pocketuni.net/seu/login",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36",
        "X-Requested-With": "XMLHttpRequest",
    }

    ses = requests.session()
    ses.get("http://pocketuni.net/")
    login_action = ses.post(login_url,headers=login_headers,data=form_data)
    print(login_action.url)

    reg_page = ses.get("http://pocketuni.net/index.php?app=home&mod=Public&act=userinfo").content
    selector=etree.HTML(reg_page)
    hash_value=selector.xpath('//input[@name="__hash__"]/@value')[0]
    print(hash_value)

    gender,district,fore_num = gen_fore_num()
    result = fore_num+gen_last_num(fore_num)
    qq_number = random.randint(1111111111,39999999999)
    mailbox = str(qq_number) + "@qq.com"
    mobile_number = input("输入手机号:")
    ses.post("http://pocketuni.net/index.php?app=home&mod=Public&act=mobileCode",data={"mobile":mobile_number})
    ver_code = input("验证码：")
    reg_form = {
        "nickname":number,
        "password": "000000",
        "repassword": "000000",
        "email2": mailbox,
        "mobile": mobile_number,
        "code": ver_code,
        "area_id": "1",
        "province_id": "17",
        "city_id": "113",
        "idcard": result,
        "sex": gender,
        "__hash__": hash_value,
    }
    reg_url = "http://pocketuni.net/index.php?app=home&mod=Public&act=userinfo"
    ses.post(reg_url,data=reg_form)

    vote_url = "http://seu.pocketuni.net/index.php?app=event&mod=Front&act=vote"
    vote_form = {
        "id":"1131053",
        "pid":"324560",
    }
    vote_action = ses.post(vote_url,data=vote_form)

number = input("输入学号：")
auto_reg(number)